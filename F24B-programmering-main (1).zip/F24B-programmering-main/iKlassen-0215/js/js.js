/**
 * file: js/js.js
 * purpose: Behaviors
 **/
console.log('Der er kontakt til js/js.js')

/**
 * JavaScript Introduktion
 */

// let a = "Hej"
// console.log(a)

/** Øvelse: Toggle Class 
 * 
 * Lav en knap, der viser eller skuler en menu
 * 
*/
/*
// HTML:
// tilføj denne knap: <button onclick="viseSkjule()">Skjule eller vise</button>

// JavaScript:
function viseSkjule() {
    var element = document.getElementById("smaller");
    element.classList.toggle("skjuler");
    // flere toggles mv. kan tilføjes her
 }
 */
